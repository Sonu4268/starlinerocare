"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { 
  Phone, 
  Menu, 
  X, 
  MessageCircle,
  PhoneCall
} from "lucide-react";
import { COMPANY_DETAILS } from "@/data/roData";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const whatsappContactUrl = `https://wa.me/91${COMPANY_DETAILS.whatsapp}?text=${encodeURIComponent(
    "Hello Star Line RO Care! I want to contact you for RO Service / Purifier inquiry."
  )}`;

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Products", href: "/products" },
    { name: "Services", href: "/services" },
    { name: "AMC Plans", href: "/amc" },
    { name: "Commercial RO", href: "/commercial" },
    { name: "About", href: "/about" },
  ];

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled
          ? "bg-white/95 backdrop-blur-md shadow-md py-1.5 border-b border-slate-100"
          : "bg-white py-2 sm:py-2.5 border-b border-slate-100"
      }`}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 sm:gap-4 min-h-[56px] sm:min-h-[64px]">
          {/* 1. Left: Brand Logo & Title with "Star Line" then "RO Care" underneath */}
          <Link href="/" className="flex items-center gap-2 sm:gap-3 shrink-0 group">
            <div className="relative w-9 h-9 sm:w-11 sm:h-11 rounded-xl overflow-hidden border border-cyan-100 shadow-sm bg-sky-50 flex items-center justify-center shrink-0">
              <Image
                src="/images/logo.jpg"
                alt="Star Line RO Care Logo"
                width={48}
                height={48}
                className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
                priority
              />
            </div>
            
            {/* Header Brand: Line 1 'Star Line', Line 2 'RO Care', Line 3 Tagline in smaller text */}
            <div className="flex flex-col justify-center">
              <span className="text-sm sm:text-base lg:text-lg font-black tracking-tight text-slate-900 group-hover:text-cyan-600 transition-colors leading-[1.1]">
                Star Line
              </span>
              <span className="text-xs sm:text-sm font-black text-cyan-600 tracking-wide leading-[1.1]">
                RO Care
              </span>
              <span className="text-[7px] sm:text-[8px] font-semibold text-slate-400 tracking-wider uppercase leading-none mt-0.5">
                Pure Water Solutions • Service & Repair
              </span>
            </div>
          </Link>

          {/* 2. Center: Navigation Links (Clean Single Line on Desktop/Tablet) */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`px-3 py-1.5 xl:px-3.5 xl:py-2 rounded-xl text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                    isActive
                      ? "text-cyan-600 bg-cyan-50 font-bold"
                      : "text-slate-700 hover:text-cyan-600 hover:bg-slate-50"
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* 3. Right: Contact Us (Direct WhatsApp) & Phone Call Button */}
          <div className="hidden sm:flex items-center gap-2 lg:gap-3 shrink-0">
            {/* Direct Phone Call Button */}
            <a
              href={`tel:${COMPANY_DETAILS.rawPhones[0]}`}
              className="flex items-center gap-2 px-3 py-1.5 text-slate-700 hover:text-cyan-600 rounded-xl hover:bg-slate-50 border border-slate-200 transition-colors shrink-0"
              title="Call Helpline"
            >
              <PhoneCall className="w-3.5 h-3.5 text-cyan-600 shrink-0" />
              <div className="flex flex-col text-left leading-tight">
                <span className="text-[9px] text-slate-400 font-medium">Helpline</span>
                <span className="text-xs font-bold text-slate-900">{COMPANY_DETAILS.phones[0]}</span>
              </div>
            </a>

            {/* Direct WhatsApp Contact Us Button */}
            <a
              href={whatsappContactUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all transform hover:-translate-y-0.5 shrink-0"
              title="Contact Us on WhatsApp"
            >
              <MessageCircle className="w-4 h-4 fill-white text-emerald-600 shrink-0" />
              <div className="flex flex-col text-left leading-tight">
                <span className="font-black">Contact Us</span>
                <span className="text-[9px] text-emerald-100 font-medium">WhatsApp</span>
              </div>
            </a>
          </div>

          {/* Mobile Right Controls (< 640px) */}
          <div className="flex items-center gap-1.5 sm:hidden shrink-0">
            {/* Quick Mobile Contact WhatsApp */}
            <a
              href={whatsappContactUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-sm"
              aria-label="Contact Us on WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white text-emerald-600" />
              <span>Contact</span>
            </a>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 px-4 pt-3 pb-6 shadow-xl animate-in slide-in-from-top duration-200">
          <div className="space-y-1 mb-4">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-3 py-2.5 rounded-xl text-base font-medium transition-colors ${
                    isActive
                      ? "text-cyan-600 bg-cyan-50 font-bold"
                      : "text-slate-700 hover:text-cyan-600 hover:bg-slate-50"
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </div>

          {/* Direct WhatsApp Contact Us for Mobile */}
          <div className="pt-3 border-t border-slate-100 space-y-2">
            <a
              href={whatsappContactUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold shadow-md"
            >
              <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
              <span>Contact Us on WhatsApp</span>
            </a>

            <a
              href={`tel:${COMPANY_DETAILS.rawPhones[0]}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-900 text-white text-xs font-bold shadow-sm"
            >
              <Phone className="w-4 h-4 text-cyan-400" />
              <span>Call Shop: {COMPANY_DETAILS.phones[0]}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
